
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import POSEvent from './pages/POSEvent';
import VehicleCheckIn from './pages/VehicleCheckIn';
import OperatorWorkflow from './pages/OperatorWorkflow';
import BoutiquePOS from './pages/BoutiquePOS';
import CustomerHistory from './pages/CustomerHistory';
import ZReport from './pages/ZReport';
import Inventory from './pages/Inventory';

const Navigation = () => {
  const location = useLocation();
  const activeTab = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-slate-200 px-6 py-2 flex justify-between items-center z-50 max-w-md mx-auto">
      <Link to="/" className={`flex flex-col items-center gap-1 ${activeTab('/') ? 'text-primary' : 'text-slate-400'}`}>
        <span className="material-symbols-outlined">dashboard</span>
        <span className="text-[10px] font-medium">Dash</span>
      </Link>
      <Link to="/pos" className={`flex flex-col items-center gap-1 ${activeTab('/pos') ? 'text-primary' : 'text-slate-400'}`}>
        <span className="material-symbols-outlined">point_of_sale</span>
        <span className="text-[10px] font-medium">POS</span>
      </Link>
      <Link to="/boutique" className={`flex flex-col items-center gap-1 ${activeTab('/boutique') ? 'text-primary' : 'text-slate-400'}`}>
        <span className="material-symbols-outlined">shopping_basket</span>
        <span className="text-[10px] font-medium">Retail</span>
      </Link>
      <Link to="/inventory" className={`flex flex-col items-center gap-1 ${activeTab('/inventory') ? 'text-primary' : 'text-slate-400'}`}>
        <span className="material-symbols-outlined">inventory_2</span>
        <span className="text-[10px] font-medium">Inv</span>
      </Link>
      <Link to="/history" className={`flex flex-col items-center gap-1 ${activeTab('/history') ? 'text-primary' : 'text-slate-400'}`}>
        <span className="material-symbols-outlined">group</span>
        <span className="text-[10px] font-medium">History</span>
      </Link>
    </nav>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen max-w-md mx-auto bg-slate-50 relative overflow-x-hidden shadow-2xl">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/pos" element={<POSEvent />} />
          <Route path="/checkin" element={<VehicleCheckIn />} />
          <Route path="/operator" element={<OperatorWorkflow />} />
          <Route path="/boutique" element={<BoutiquePOS />} />
          <Route path="/history" element={<CustomerHistory />} />
          <Route path="/zreport" element={<ZReport />} />
          <Route path="/inventory" element={<Inventory />} />
        </Routes>
        <Navigation />
      </div>
    </Router>
  );
};

export default App;
