
export enum ServiceStatus {
  READY = 'Ready',
  IN_PROGRESS = 'In Progress',
  DELAYED = 'Delayed',
  FINISHING = 'Finishing'
}

export interface Vehicle {
  plate: string;
  model: string;
  color: string;
  image?: string;
}

export interface Bay {
  id: number;
  status: ServiceStatus;
  vehicle?: Vehicle;
  serviceName: string;
  phase: string;
  progress: number;
  timeElapsed: string;
  timeGoal: string;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  stock: number;
  image: string;
}

export interface LoyaltyMember {
  name: string;
  status: string;
  id: string;
  progress: number;
  totalRequired: number;
  memberSince: string;
}
