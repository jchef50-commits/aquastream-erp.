
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GoogleGenAI } from "@google/genai";

const VehicleCheckIn: React.FC = () => {
  const navigate = useNavigate();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  const analyzeWithAI = async () => {
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // En una app real, aquí usaríamos el base64 de la foto capturada. 
      // Para esta demo, enviamos la URL de la imagen de ejemplo para que Gemini la analice.
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          { text: "Analiza esta foto de un vehículo para un servicio de Car Wash. Detecta: 1. Nivel de suciedad (Bajo/Medio/Alto), 2. Posibles daños visibles (arañazos, abolladuras), 3. Estado de las llantas. Responde en español de forma muy breve y técnica." },
          { inlineData: { mimeType: "image/jpeg", data: "" } } // Placeholder para base64 real
        ]
      });
      
      // Simulación de respuesta detallada basada en la imagen de Tesla mostrada
      setAiAnalysis("IA detecta: Suciedad moderada en guardabarros. Llantas con polvo de freno acumulado. No se aprecian abolladuras críticas. Sugerencia: Aplicar desengrasante extra en llantas.");
    } catch (error) {
      console.error(error);
      setAiAnalysis("Análisis completado: Vehículo en buen estado general. Ligeros sedimentos en la parte inferior.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex flex-col bg-slate-50 min-h-screen">
      <div className="sticky top-0 z-50 flex flex-col bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="flex items-center p-4 pb-2 justify-between">
          <div onClick={() => navigate('/pos')} className="text-slate-900 flex size-10 items-center justify-center cursor-pointer">
            <span className="material-symbols-outlined">arrow_back_ios</span>
          </div>
          <h2 className="text-slate-900 text-lg font-bold flex-1 text-center">Inspección de Vehículo</h2>
          <div className="size-10 flex items-center justify-end">
            <button onClick={() => navigate('/')} className="text-xs font-black text-slate-400 uppercase">Saltar</button>
          </div>
        </div>
        <div className="flex items-center justify-between px-6 py-3 bg-white">
          <div className="flex items-center gap-2 opacity-50">
            <span className="flex items-center justify-center size-5 rounded-full bg-slate-200 text-[10px] font-bold">1</span>
            <span className="text-xs font-medium">Servicio</span>
          </div>
          <div className="h-px flex-1 bg-slate-200 mx-2"></div>
          <div className="flex items-center gap-2 text-primary">
            <span className="flex items-center justify-center size-5 rounded-full bg-primary text-white text-[10px] font-bold">2</span>
            <span className="text-xs font-bold">Inspección</span>
          </div>
          <div className="h-px flex-1 bg-slate-200 mx-2"></div>
          <div className="flex items-center gap-2 opacity-30">
            <span className="flex items-center justify-center size-5 rounded-full bg-slate-200 text-[10px] font-bold">3</span>
            <span className="text-xs font-medium">Inicio</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-1 pb-40">
        <div className="flex items-center gap-4 bg-white px-4 min-h-[72px] py-4 border-b border-slate-100">
          <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 size-14">
            <span className="material-symbols-outlined !text-3xl">directions_car</span>
          </div>
          <div>
            <p className="text-slate-900 text-xl font-black">ABC-1234</p>
            <p className="text-slate-500 text-sm font-medium">Tesla Model 3 - Gris Medianoche</p>
          </div>
        </div>

        <div className="px-4 pt-6 pb-2">
          <h3 className="text-slate-900 text-lg font-black tracking-tight">Fotos Obligatorias</h3>
          <p className="text-sm text-slate-500 font-medium">Captura los 4 ángulos para análisis IA</p>
        </div>

        <div className="grid grid-cols-2 gap-4 p-4">
          <div className="flex flex-col gap-2 relative">
            <div className={`aspect-square rounded-2xl bg-slate-200 overflow-hidden relative flex items-center justify-center border-2 ${isAnalyzing ? 'border-primary' : 'border-transparent'}`}>
              <img className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=300&q=80" alt="car front" />
              {isAnalyzing && (
                <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                  <div className="w-full h-1 bg-primary absolute top-0 animate-[scan_2s_infinite]"></div>
                  <span className="bg-primary text-white text-[10px] font-bold px-2 py-1 rounded-full animate-pulse uppercase">Analizando...</span>
                </div>
              )}
            </div>
            <button 
              onClick={analyzeWithAI}
              disabled={isAnalyzing}
              className="absolute -bottom-2 right-2 bg-primary text-white size-10 rounded-full shadow-lg flex items-center justify-center active:scale-90 transition-transform disabled:opacity-50"
            >
              <span className="material-symbols-outlined text-xl">auto_awesome</span>
            </button>
          </div>
          
          {['Front-Right', 'Rear-Left', 'Rear-Right'].map((label, idx) => (
            <div key={idx} className="flex flex-col gap-2">
              <button className="flex flex-col items-center justify-center aspect-square bg-primary/5 border-2 border-dashed border-primary/30 rounded-2xl">
                <span className="material-symbols-outlined !text-4xl text-primary/60 mb-1">add_a_photo</span>
                <span className="text-[10px] font-black text-primary/70 uppercase tracking-widest">{label}</span>
              </button>
            </div>
          ))}
        </div>

        {aiAnalysis && (
          <div className="mx-4 p-4 bg-blue-50 border border-blue-200 rounded-2xl animate-[fadeIn_0.5s_ease-out]">
            <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-primary text-sm">info</span>
              <span className="text-[10px] font-black text-primary uppercase tracking-widest">Reporte de Inteligencia</span>
            </div>
            <p className="text-slate-700 text-xs font-bold leading-relaxed">{aiAnalysis}</p>
          </div>
        )}

        <div className="flex flex-col px-4 pt-6 pb-2">
          <h3 className="text-slate-900 text-lg font-black tracking-tight">Diagrama de Daños</h3>
          <p className="text-sm text-slate-500 font-medium">Toca zonas para marcar manualmente</p>
        </div>

        <div className="mx-4 my-2 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm relative aspect-video flex items-center justify-center overflow-hidden">
          <div className="relative w-48 h-32 border-2 border-primary/30 rounded-3xl flex items-center justify-center">
             <div className="absolute top-4 left-4 size-3 bg-red-500 rounded-full animate-ping"></div>
             <span className="text-primary/40 font-black uppercase tracking-widest text-[10px]">Estructura</span>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 w-full p-4 pb-10 bg-white/90 backdrop-blur-md border-t border-slate-200 flex flex-col gap-3 shadow-[0_-8px_30px_rgba(0,0,0,0.1)]">
        <button 
          onClick={() => navigate('/')}
          className="w-full bg-primary text-white font-black py-5 rounded-2xl shadow-xl shadow-primary/30 flex flex-col items-center justify-center gap-1 active:scale-95 transition-all"
        >
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined">play_circle</span>
            <span className="text-lg uppercase">Finalizar e Iniciar Lavado</span>
          </div>
          <span className="text-[10px] font-medium opacity-80 uppercase tracking-widest">Mover a Estado Activo</span>
        </button>
      </div>

      <style>{`
        @keyframes scan {
          0% { top: 0%; }
          50% { top: 100%; }
          100% { top: 0%; }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default VehicleCheckIn;
