
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';

const ZReport: React.FC = () => {
  const navigate = useNavigate();
  const [cashCounted, setCashCounted] = useState('$1,070.00');

  const data = [
    { name: 'Cash', value: 1120 },
    { name: 'Credit', value: 1450 },
    { name: 'Digital', value: 270 }
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-32">
      <div className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="flex items-center p-4 justify-between">
          <div onClick={() => navigate('/')} className="text-primary flex size-12 shrink-0 items-center justify-start cursor-pointer">
            <span className="material-symbols-outlined">arrow_back_ios</span>
          </div>
          <h2 className="text-lg font-black tracking-tight text-center flex-1 pr-12 uppercase">Z-Report & Cash Out</h2>
          <div className="size-12 flex items-center justify-end">
            <span className="material-symbols-outlined text-primary cursor-pointer">print</span>
          </div>
        </div>
      </div>

      <main className="max-w-md mx-auto p-4 space-y-6">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[100px] flex flex-col gap-1 rounded-2xl p-4 bg-white shadow-sm border border-slate-100">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Total Sales</p>
            <p className="text-primary tracking-tighter text-2xl font-black">$2,840.50</p>
          </div>
          <div className="flex-1 min-w-[100px] flex flex-col gap-1 rounded-2xl p-4 bg-white shadow-sm border border-slate-100">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Services</p>
            <p className="text-slate-900 tracking-tighter text-2xl font-black">84</p>
          </div>
          <div className="flex-1 min-w-[100px] flex flex-col gap-1 rounded-2xl p-4 bg-white shadow-sm border border-slate-100">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Drawer Cash</p>
            <p className="text-success tracking-tighter text-2xl font-black">$1,120.00</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
          <div className="flex flex-col gap-1 mb-6">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Sales by Method</p>
            <p className="text-2xl font-black tracking-tighter">$2,840.50</p>
          </div>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#94a3b8' }} />
                <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={index} fill={index === 1 ? '#137fec' : index === 0 ? '#137fec99' : '#137fec33'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <h3 className="text-slate-900 text-sm font-black uppercase tracking-widest">Payment Breakdown</h3>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 divide-y divide-slate-50">
          {[
            { label: 'Cash Sales', icon: 'payments', value: '$1,120.00' },
            { label: 'Credit Card', icon: 'credit_card', value: '$1,450.50' },
            { label: 'Digital Wallets', icon: 'contactless', value: '$270.00' }
          ].map((item, idx) => (
            <div key={idx} className="flex justify-between items-center p-4">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-slate-300">{item.icon}</span>
                <p className="text-slate-600 text-sm font-bold">{item.label}</p>
              </div>
              <p className="font-black text-sm tracking-tighter">{item.value}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mb-3">Tips Earned</p>
            <div className="flex items-center justify-between">
              <span className="material-symbols-outlined text-amber-500 text-xl">loyalty</span>
              <p className="font-black text-lg tracking-tighter">$142.00</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mb-3">Daily Expenses</p>
            <div className="flex items-center justify-between">
              <span className="material-symbols-outlined text-danger text-xl">shopping_cart</span>
              <p className="font-black text-lg tracking-tighter text-danger">-$45.00</p>
            </div>
          </div>
        </div>

        <div className="p-3 bg-slate-200/50 rounded-xl flex justify-between items-center text-[10px] text-slate-500 font-bold uppercase tracking-tighter">
          <span className="italic">Soap refill & snacks</span>
          <span className="opacity-70">ID: #EXP-9021</span>
        </div>

        <h3 className="text-slate-900 text-sm font-black uppercase tracking-widest">Cash Reconciliation</h3>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-xs font-bold uppercase tracking-tighter">Expected Cash</p>
            <p className="font-black tracking-tighter">$1,075.00</p>
          </div>
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-xs font-bold uppercase tracking-tighter">Actual Counted</p>
            <input 
              className="bg-slate-50 border-slate-200 rounded-xl text-right w-28 p-2 text-sm font-black tracking-tighter focus:ring-primary focus:border-primary" 
              type="text" 
              value={cashCounted}
              onChange={(e) => setCashCounted(e.target.value)}
            />
          </div>
          <div className="pt-3 border-t border-dashed border-slate-200 flex justify-between items-center">
            <p className="text-slate-900 font-black text-sm uppercase tracking-tighter">Difference</p>
            <p className="text-danger font-black text-lg tracking-tighter">-$5.00</p>
          </div>
        </div>

        <button className="w-full bg-primary hover:bg-primary/90 text-white font-black py-4 px-6 rounded-2xl shadow-xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-[0.98] transition-all uppercase tracking-tight">
          <span className="material-symbols-outlined">description</span>
          Close Register & Generate PDF
        </button>
      </main>
    </div>
  );
};

export default ZReport;
