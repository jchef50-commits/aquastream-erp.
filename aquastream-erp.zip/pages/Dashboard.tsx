
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Bay, ServiceStatus } from '../types';
import AIAssistant from '../components/AIAssistant';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();

  const bays: Bay[] = [
    {
      id: 1,
      status: ServiceStatus.IN_PROGRESS,
      vehicle: { plate: 'ABC-1234', model: 'Tesla M3', color: 'Midnight Silver', image: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=200&q=80' },
      serviceName: 'Ceramic Wash',
      phase: 'Scrubbing',
      progress: 65,
      timeElapsed: '08:45',
      timeGoal: '12:00'
    },
    {
      id: 2,
      status: ServiceStatus.DELAYED,
      vehicle: { plate: 'F-150', model: 'Ford F-150', color: 'Black', image: 'https://images.unsplash.com/photo-1590333746438-28358278531c?auto=format&fit=crop&w=200&q=80' },
      serviceName: 'Express Wax',
      phase: 'Rinsing',
      progress: 95,
      timeElapsed: '14:10',
      timeGoal: '12:00'
    },
    {
      id: 3,
      status: ServiceStatus.READY,
      serviceName: '',
      phase: 'Waiting for vehicle',
      progress: 0,
      timeElapsed: '--:--',
      timeGoal: '--:--'
    },
    {
      id: 4,
      status: ServiceStatus.READY,
      serviceName: '',
      phase: 'Waiting for vehicle',
      progress: 0,
      timeElapsed: '--:--',
      timeGoal: '--:--'
    }
  ];

  const businessContext = {
    activeBays: bays.filter(b => b.status !== ServiceStatus.READY),
    summary: { rev: 1240, done: 42, active: 5 }
  };

  return (
    <div className="pb-24">
      {/* Top Header */}
      <div className="flex items-center bg-white/80 backdrop-blur-md p-4 pb-3 justify-between sticky top-0 z-30 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="bg-primary rounded-lg p-1.5">
            <span className="material-symbols-outlined text-white text-xl">local_car_wash</span>
          </div>
          <h2 className="text-slate-900 text-lg font-bold">Manager</h2>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => navigate('/zreport')} className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
            <span className="material-symbols-outlined text-sm text-slate-500">payments</span>
            <span className="text-xs font-bold text-slate-700 uppercase">Cash Out</span>
          </button>
          <div className="relative h-10 w-10 bg-slate-100 rounded-full flex items-center justify-center">
             <span className="material-symbols-outlined text-slate-600">notifications</span>
             <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="flex gap-2 p-3 overflow-x-auto no-scrollbar">
        <div className="flex min-w-[100px] flex-1 items-center gap-2 rounded-xl p-3 bg-white border border-slate-200">
          <span className="material-symbols-outlined text-primary">payments</span>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Rev</p>
            <p className="text-sm font-bold">$1,240</p>
          </div>
        </div>
        <div className="flex min-w-[100px] flex-1 items-center gap-2 rounded-xl p-3 bg-white border border-slate-200">
          <span className="material-symbols-outlined text-success">task_alt</span>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Done</p>
            <p className="text-sm font-bold">42</p>
          </div>
        </div>
        <div className="flex min-w-[100px] flex-1 items-center gap-2 rounded-xl p-3 bg-primary/10 border border-primary/20">
          <span className="material-symbols-outlined text-primary">timer</span>
          <div>
            <p className="text-[10px] text-primary font-bold uppercase">Active</p>
            <p className="text-sm font-bold text-primary">5</p>
          </div>
        </div>
      </div>

      {/* Bay List */}
      <div className="px-3 pb-4">
        <div className="flex items-center justify-between py-2 px-1">
          <h3 className="text-slate-900 font-bold text-base">Bay Status</h3>
          <span className="text-[11px] text-slate-500 font-medium">8 Staff On Duty</span>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {bays.map((bay) => (
            <button 
              key={bay.id}
              onClick={() => bay.status !== ServiceStatus.READY && navigate('/operator')}
              className={`w-full text-left flex flex-col gap-3 p-4 rounded-2xl bg-white shadow-sm border-l-4 transition-transform active:scale-[0.98] ${
                bay.status === ServiceStatus.IN_PROGRESS ? 'border-l-warning' : 
                bay.status === ServiceStatus.DELAYED ? 'border-l-danger' : 
                'border-l-success opacity-80'
              }`}
            >
              <div className="flex justify-between items-start w-full">
                <div className="flex gap-3 items-center">
                  {bay.vehicle ? (
                    <div className="w-12 h-12 rounded-xl bg-center bg-cover border border-slate-100" style={{ backgroundImage: `url(${bay.vehicle.image})` }}></div>
                  ) : (
                    <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-success/10 text-success">
                      <span className="material-symbols-outlined text-2xl">check_circle</span>
                    </div>
                  )}
                  <div>
                    <h4 className="font-bold text-slate-900 text-base">Bay {bay.id} • {bay.vehicle?.plate || 'Ready'}</h4>
                    <p className="text-slate-500 text-xs font-medium">{bay.serviceName ? `${bay.serviceName} • ${bay.phase}` : bay.phase}</p>
                  </div>
                </div>
                {bay.status !== ServiceStatus.READY && (
                  <div className="text-right">
                    <span className={`text-[10px] font-black uppercase tracking-wider block ${bay.status === ServiceStatus.DELAYED ? 'text-danger' : 'text-warning'}`}>
                      {bay.status === ServiceStatus.DELAYED ? 'Delayed +2m' : 'In Progress'}
                    </span>
                    <span className="text-slate-900 font-bold text-sm">{bay.timeElapsed}</span>
                  </div>
                )}
              </div>
              {bay.status !== ServiceStatus.READY && (
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-500 ${bay.status === ServiceStatus.DELAYED ? 'bg-danger' : 'bg-warning'}`} style={{ width: `${bay.progress}%` }}></div>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      <AIAssistant businessData={businessContext} />

      <button onClick={() => navigate('/pos')} className="fixed bottom-24 right-6 w-16 h-16 bg-primary text-white rounded-full shadow-2xl flex items-center justify-center z-40 active:scale-90 transition-transform ring-4 ring-white">
        <span className="material-symbols-outlined text-3xl">add</span>
      </button>
    </div>
  );
};

export default Dashboard;
