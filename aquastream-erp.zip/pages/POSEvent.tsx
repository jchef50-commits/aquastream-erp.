
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const POSEvent: React.FC = () => {
  const navigate = useNavigate();
  const [vehicleType, setVehicleType] = useState('Sedan');
  const [servicePackage, setServicePackage] = useState('Premium');

  return (
    <div className="h-screen flex flex-col bg-white">
      <div className="bg-white shrink-0 shadow-sm z-30">
        <div className="flex items-center p-4">
          <div onClick={() => navigate('/')} className="text-primary flex size-10 items-center justify-center cursor-pointer active:opacity-50">
            <span className="material-symbols-outlined font-bold">arrow_back_ios_new</span>
          </div>
          <h2 className="text-slate-900 text-xl font-extrabold leading-tight flex-1 text-center pr-10 tracking-tight">EXPRESS POS</h2>
        </div>
        <div className="flex items-center justify-between px-6 pb-4 pt-2">
          <div className="flex flex-col items-center gap-1">
            <div className="h-1.5 w-24 rounded-full bg-primary"></div>
            <span className="text-[10px] font-black text-primary uppercase tracking-tighter">1. Service</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="h-1.5 w-24 rounded-full bg-slate-200"></div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">2. Inspection</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="h-1.5 w-24 rounded-full bg-slate-200"></div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">3. Start</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-72">
        <div className="px-4 py-6 bg-slate-50 border-b border-slate-100">
          <div className="flex w-full items-stretch rounded-2xl h-16 shadow-sm border-2 border-slate-200 bg-white focus-within:border-primary transition-colors">
            <div className="text-slate-400 flex items-center justify-center pl-5">
              <span className="material-symbols-outlined text-3xl">directions_car</span>
            </div>
            <input 
              className="flex w-full border-none bg-transparent focus:outline-0 focus:ring-0 text-slate-900 placeholder:text-slate-400 px-4 text-2xl font-bold uppercase tracking-wider" 
              placeholder="LICENSE PLATE" 
              defaultValue="ABC-1234"
            />
          </div>
        </div>

        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-slate-900 text-xs font-black uppercase tracking-widest">Vehicle</h3>
            <span className="text-[10px] font-bold text-primary bg-blue-50 px-2 py-0.5 rounded">AUTO-DETECTED</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => setVehicleType('Sedan')}
              className={`flex flex-col gap-3 rounded-2xl border-4 p-6 items-center justify-center transition-all active:scale-95 ${vehicleType === 'Sedan' ? 'border-primary bg-primary/5' : 'border-slate-100 bg-white opacity-60'}`}
            >
              <span className={`material-symbols-outlined text-5xl ${vehicleType === 'Sedan' ? 'text-primary' : 'text-slate-400'}`}>directions_car</span>
              <h2 className={`text-lg font-black uppercase ${vehicleType === 'Sedan' ? 'text-primary' : 'text-slate-500'}`}>Sedan</h2>
            </button>
            <button 
              onClick={() => setVehicleType('SUV')}
              className={`flex flex-col gap-3 rounded-2xl border-4 p-6 items-center justify-center transition-all active:scale-95 ${vehicleType === 'SUV' ? 'border-primary bg-primary/5' : 'border-slate-100 bg-white opacity-60'}`}
            >
              <span className={`material-symbols-outlined text-5xl ${vehicleType === 'SUV' ? 'text-primary' : 'text-slate-400'}`}>airport_shuttle</span>
              <h2 className={`text-lg font-black uppercase ${vehicleType === 'SUV' ? 'text-primary' : 'text-slate-500'}`}>SUV</h2>
            </button>
          </div>
        </div>

        <div className="px-4 py-4">
          <h3 className="text-slate-900 text-xs font-black uppercase tracking-widest mb-3">Service</h3>
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => setServicePackage('Basic')}
              className={`flex flex-col gap-3 rounded-2xl border-4 p-6 items-center justify-center transition-all active:scale-95 ${servicePackage === 'Basic' ? 'border-primary bg-primary/5' : 'border-slate-100 bg-white opacity-60'}`}
            >
              <span className={`material-symbols-outlined text-5xl ${servicePackage === 'Basic' ? 'text-primary' : 'text-slate-400'}`}>water_drop</span>
              <h2 className={`text-lg font-black uppercase ${servicePackage === 'Basic' ? 'text-primary' : 'text-slate-500'}`}>Basic</h2>
            </button>
            <button 
              onClick={() => setServicePackage('Premium')}
              className={`flex flex-col gap-3 rounded-2xl border-4 p-6 items-center justify-center transition-all active:scale-95 ${servicePackage === 'Premium' ? 'border-primary bg-primary/5' : 'border-slate-100 bg-white opacity-60'}`}
            >
              <span className={`material-symbols-outlined text-5xl ${servicePackage === 'Premium' ? 'text-primary' : 'text-slate-400'}`}>workspace_premium</span>
              <h2 className={`text-lg font-black uppercase ${servicePackage === 'Premium' ? 'text-primary' : 'text-slate-500'}`}>Premium</h2>
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-white border-t-4 border-slate-50 p-4 pb-10 flex flex-col gap-3 shadow-[0_-8px_30px_rgba(0,0,0,0.1)] z-40">
        <div className="flex justify-between items-center px-2 mb-1">
          <div className="flex flex-col">
            <span className="text-slate-400 font-bold text-[10px] tracking-widest uppercase">Total Bill</span>
            <span className="text-4xl font-black text-slate-900">$45.00</span>
          </div>
          <div className="bg-blue-50 px-3 py-2 rounded-xl border border-blue-100 flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-xl">verified</span>
            <span className="text-primary font-black text-xs uppercase tracking-tighter leading-none">Order<br/>Ready</span>
          </div>
        </div>
        <div className="flex flex-col gap-3">
          <button 
            onClick={() => navigate('/checkin')}
            className="w-full h-20 bg-primary text-white rounded-2xl font-black text-2xl shadow-xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-[0.98] transition-all uppercase tracking-tight"
          >
            <span className="material-symbols-outlined text-3xl">fact_check</span>
            Proceed to Inspection
          </button>
          <button className="w-full h-14 bg-slate-100 text-slate-500 rounded-xl font-black text-sm flex items-center justify-center gap-2 uppercase tracking-tighter">
            <span className="material-symbols-outlined text-xl">bolt</span>
            Skip to Start (Manager Only)
          </button>
        </div>
      </div>
    </div>
  );
};

export default POSEvent;
