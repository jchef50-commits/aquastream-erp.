
import React from 'react';
import { useNavigate } from 'react-router-dom';

const CustomerHistory: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="flex items-center bg-white p-4 pb-2 justify-between sticky top-0 z-30 border-b border-slate-200">
        <div onClick={() => navigate('/')} className="text-primary flex size-12 shrink-0 items-center cursor-pointer">
          <span className="material-symbols-outlined">arrow_back_ios</span>
        </div>
        <h2 className="text-slate-900 text-lg font-black tracking-tight flex-1 text-center pr-12 uppercase">Customer History</h2>
      </div>

      <div className="px-4 py-3">
        <div className="flex w-full items-stretch rounded-2xl h-12 shadow-sm bg-white border border-slate-200">
          <div className="text-slate-400 flex items-center justify-center pl-4">
            <span className="material-symbols-outlined">search</span>
          </div>
          <input className="flex w-full border-none bg-transparent focus:ring-0 text-slate-900 placeholder:text-slate-400 px-4 text-sm font-medium" placeholder="Search plate or phone..." defaultValue="ABC-1234"/>
        </div>
      </div>

      <div className="p-4">
        <div className="flex flex-col items-stretch justify-start rounded-2xl shadow-xl bg-primary text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
          <div className="p-6 relative z-10">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-blue-100 text-[10px] font-black uppercase tracking-widest opacity-80">Loyalty Member</p>
                <p className="text-2xl font-black tracking-tight">Gold Status</p>
              </div>
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md border border-white/10">
                <span className="material-symbols-outlined text-white text-2xl">workspace_premium</span>
              </div>
            </div>
            <div className="flex flex-col gap-2 mt-6">
              <div className="flex justify-between items-end">
                <p className="text-xs font-bold text-white/90">4 more washes for a free wash!</p>
                <p className="text-[10px] font-black bg-white/20 px-2 py-0.5 rounded-full">6 / 10</p>
              </div>
              <div className="h-2 rounded-full bg-white/20 overflow-hidden">
                <div className="h-full bg-white rounded-full shadow-[0_0_10px_white]" style={{ width: '60%' }}></div>
              </div>
            </div>
            <div className="mt-5 pt-4 border-t border-white/10 flex justify-between items-center text-[10px] font-bold text-blue-100 uppercase tracking-widest">
              <span>Since May 2023</span>
              <span className="opacity-70">ID: #882910</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <h2 className="text-slate-900 text-lg font-black tracking-tight uppercase">Recent Services</h2>
        <span className="text-primary text-xs font-black uppercase tracking-widest cursor-pointer">View All</span>
      </div>

      <div className="p-4 space-y-4">
        {[
          { date: 'TODAY, 10:30 AM', name: 'Premium Full Detail', car: 'Tesla Model 3 • Black', price: '$45.00', tags: ['Exterior Wax', 'Interior Vacuum', 'Tire Shine'] },
          { date: 'OCT 12, 2023', name: 'Standard Wash', car: 'Tesla Model 3 • Black', price: '$25.00', tags: ['Exterior Wash', 'Drying'] },
          { date: 'SEP 28, 2023', name: 'Ceramic Coating Prep', car: 'Tesla Model 3 • Black', price: '$120.00', tags: ['Clay Bar', 'Polish'] }
        ].map((service, idx) => (
          <div key={idx} className="relative pl-6 border-l-2 border-primary/20 pb-4">
            <div className={`absolute -left-[9px] top-0 size-4 rounded-full border-4 border-slate-50 ${idx === 0 ? 'bg-primary' : 'bg-slate-300'}`}></div>
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1">{service.date}</p>
                  <p className="text-slate-900 text-base font-black tracking-tighter">{service.name}</p>
                  <p className="text-xs text-slate-500 font-medium">{service.car}</p>
                </div>
                <p className="text-primary font-black text-lg tracking-tighter">{service.price}</p>
              </div>
              <div className="flex flex-wrap gap-2 mb-4">
                {service.tags.map((tag, tIdx) => (
                  <span key={tIdx} className="text-[9px] font-black uppercase tracking-widest bg-slate-100 text-slate-500 px-2 py-1 rounded-md">{tag}</span>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button className="flex items-center justify-center gap-2 py-2.5 bg-primary/5 text-primary rounded-xl text-[10px] font-black uppercase tracking-widest border border-primary/10 transition-colors hover:bg-primary hover:text-white">
                  <span className="material-symbols-outlined !text-sm">call</span>
                  Call
                </button>
                <button className="flex items-center justify-center gap-2 py-2.5 bg-success/5 text-success rounded-xl text-[10px] font-black uppercase tracking-widest border border-success/10 transition-colors hover:bg-success hover:text-white">
                  <span className="material-symbols-outlined !text-sm">chat</span>
                  WhatsApp
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomerHistory;
