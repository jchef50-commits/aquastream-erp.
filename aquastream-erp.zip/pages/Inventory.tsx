
import React from 'react';
import { useNavigate } from 'react-router-dom';

const Inventory: React.FC = () => {
  const navigate = useNavigate();

  const items = [
    { name: 'Premium Car Shampoo', level: 12, total: 100, unit: 'Gallons', updated: '2h ago', alert: true, img: 'https://images.unsplash.com/photo-1595433707802-68267d837c0a?auto=format&fit=crop&w=200&q=80' },
    { name: 'Ceramic Wax Coat', level: 45, total: 50, unit: 'Units', updated: 'Yesterday', alert: false, img: 'https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=200&q=80' },
    { name: 'Extreme Tire Shine', level: 8, total: 40, unit: 'Units', updated: '3 days ago', alert: true, img: 'https://images.unsplash.com/photo-1598501479155-208d88321453?auto=format&fit=crop&w=200&q=80' },
    { name: 'Microfiber Packs', level: 200, total: 300, unit: 'Packs', updated: 'Just now', alert: false, img: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=200&q=80' },
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="flex items-center p-4 justify-between max-w-lg mx-auto">
          <div className="flex items-center gap-3">
            <span onClick={() => navigate('/')} className="material-symbols-outlined text-slate-900 text-2xl cursor-pointer">menu</span>
            <h2 className="text-lg font-black tracking-tight uppercase">Inventory</h2>
          </div>
          <div className="flex gap-2">
            <button className="p-2 rounded-full hover:bg-slate-100">
              <span className="material-symbols-outlined">search</span>
            </button>
            <button className="p-2 rounded-full hover:bg-slate-100">
              <span className="material-symbols-outlined">add_circle</span>
            </button>
          </div>
        </div>
        <div className="flex border-b border-slate-100 px-4 gap-8">
          {['All Items', 'Low Stock', 'Analytics'].map((tab, idx) => (
            <div key={idx} className={`flex flex-col items-center justify-center border-b-4 py-3 cursor-pointer ${idx === 0 ? 'border-primary text-primary' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>
              <p className="text-xs font-black uppercase tracking-widest">{tab}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="flex items-start justify-between gap-4 rounded-2xl border border-red-200 bg-red-50 p-5 shadow-sm">
          <div className="flex gap-3">
            <span className="material-symbols-outlined text-danger">warning</span>
            <div className="flex flex-col gap-1">
              <p className="text-slate-900 text-base font-black uppercase tracking-tighter">Critical Low Stock</p>
              <p className="text-slate-500 text-xs font-bold">3 items are below threshold.</p>
            </div>
          </div>
          <button className="flex h-9 px-4 bg-primary text-white text-[10px] font-black uppercase tracking-widest rounded-xl shadow-lg shadow-primary/30">
            Restock All
          </button>
        </div>

        <div className="space-y-3">
          {items.map((item, idx) => (
            <div key={idx} className="flex flex-col gap-3 bg-white rounded-2xl p-4 border border-slate-200 shadow-sm transition-transform active:scale-[0.98]">
              <div className="flex gap-4 justify-between">
                <div className="flex items-start gap-4">
                  <div className="bg-center bg-cover rounded-xl size-16 shrink-0 shadow-inner" style={{ backgroundImage: `url(${item.img})` }}></div>
                  <div className="flex flex-1 flex-col justify-center">
                    <p className="text-slate-900 text-sm font-black tracking-tighter uppercase">{item.name}</p>
                    <p className="text-slate-400 text-[9px] font-bold uppercase tracking-widest">Updated: {item.updated}</p>
                    <p className="text-slate-900 text-sm font-black mt-1 tracking-tighter">{item.level} / {item.total} {item.unit}</p>
                  </div>
                </div>
                <button className={`h-9 px-4 text-[10px] font-black uppercase tracking-widest rounded-xl shadow-md ${item.alert ? 'bg-primary text-white shadow-primary/20' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
                  {item.alert ? 'Restock' : 'Details'}
                </button>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-1 overflow-hidden">
                <div className={`h-full rounded-full transition-all duration-700 ${item.level / item.total < 0.25 ? 'bg-danger' : 'bg-success'}`} style={{ width: `${(item.level / item.total) * 100}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Inventory;
