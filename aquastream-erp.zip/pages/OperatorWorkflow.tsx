
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const OperatorWorkflow: React.FC = () => {
  const navigate = useNavigate();
  const [seconds, setSeconds] = useState(0);
  const [checklist, setChecklist] = useState([
    { id: 1, label: 'Exterior Wash', completed: true },
    { id: 2, label: 'Interior Vacuuming', completed: false },
    { id: 3, label: 'Premium Waxing', completed: false },
    { id: 4, label: 'Tire Shine', completed: false },
  ]);

  useEffect(() => {
    const timer = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (total: number) => {
    const m = Math.floor(total / 60);
    const s = total % 60;
    return {
      min: m.toString().padStart(2, '0'),
      sec: s.toString().padStart(2, '0')
    };
  };

  const toggleTask = (id: number) => {
    setChecklist(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const time = formatTime(seconds);

  return (
    <div className="flex flex-col bg-slate-900 min-h-screen text-white">
      <div className="flex items-center bg-[#111a22] p-4 border-b border-white/10 sticky top-0 z-30">
        <div onClick={() => navigate('/')} className="text-white flex size-12 shrink-0 items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined text-2xl">arrow_back</span>
        </div>
        <h2 className="text-white text-lg font-bold flex-1 text-center pr-12">Bay 1 Operator</h2>
        <div className="text-primary flex size-12 shrink-0 items-center justify-center">
          <span className="material-symbols-outlined text-2xl">notifications</span>
        </div>
      </div>

      <div className="flex bg-[#111a22] px-4">
        <div className="flex-1 border-b-4 border-primary py-3 text-center">
          <p className="text-xs font-black text-white uppercase tracking-widest">Current Task</p>
        </div>
        <div className="flex-1 border-b-4 border-transparent py-3 text-center opacity-40">
          <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Upcoming</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-40">
        <h2 className="text-white text-xl font-black px-4 pt-6 pb-3">Current Vehicle</h2>
        <div className="px-4">
          <div className="flex items-stretch justify-between gap-4 rounded-2xl bg-[#192633] p-5 shadow-2xl border border-white/5">
            <div className="flex flex-col gap-1 flex-[2_2_0px] justify-center">
              <p className="text-primary text-[10px] font-black uppercase tracking-widest">In Progress</p>
              <p className="text-white text-3xl font-black leading-tight">ABC-1234</p>
              <p className="text-slate-400 text-sm font-medium">Tesla Model 3 • Silver</p>
            </div>
            <div className="w-32 h-24 bg-center bg-cover rounded-xl" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=300&q=80')` }}></div>
          </div>
        </div>

        <h2 className="text-white text-xl font-black px-4 pt-8 pb-3">Service Timer</h2>
        <div className="flex gap-4 px-4">
          <div className="flex grow basis-0 flex-col gap-2">
            <div className="flex h-20 items-center justify-center rounded-2xl bg-[#233648] border border-white/10">
              <p className="text-white text-4xl font-black">{time.min}</p>
            </div>
            <p className="text-center text-slate-500 text-[10px] font-black uppercase">Min</p>
          </div>
          <div className="flex grow basis-0 flex-col gap-2">
            <div className="flex h-20 items-center justify-center rounded-2xl bg-[#233648] border border-white/10">
              <p className="text-white text-4xl font-black">{time.sec}</p>
            </div>
            <p className="text-center text-slate-500 text-[10px] font-black uppercase">Sec</p>
          </div>
          <div className="flex grow basis-0 flex-col gap-2 opacity-40">
            <div className="flex h-20 items-center justify-center rounded-2xl bg-[#111a22] border border-white/5">
              <p className="text-white text-4xl font-black">15</p>
            </div>
            <p className="text-center text-slate-500 text-[10px] font-black uppercase">Goal</p>
          </div>
        </div>

        <h2 className="text-white text-xl font-black px-4 pt-8 pb-3">Service Checklist</h2>
        <div className="px-4 flex flex-col gap-3">
          {checklist.map((task) => (
            <button 
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className="flex items-center justify-between bg-[#192633] p-5 rounded-2xl border border-white/5 transition-all active:scale-[0.98]"
            >
              <div className="flex items-center gap-4 text-left">
                <span className={`material-symbols-outlined text-3xl ${task.completed ? 'text-primary' : 'text-slate-500'}`}>
                  {task.id === 1 ? 'wash' : task.id === 2 ? 'vacuum' : task.id === 3 ? 'layers' : 'tire_repair'}
                </span>
                <p className={`text-lg font-bold ${task.completed ? 'text-white' : 'text-slate-400'}`}>{task.label}</p>
              </div>
              <div className={`size-8 rounded-full border-2 flex items-center justify-center transition-colors ${task.completed ? 'border-primary bg-primary' : 'border-slate-700'}`}>
                {task.completed && <span className="material-symbols-outlined text-white text-xl">check</span>}
              </div>
            </button>
          ))}
        </div>

        <div className="p-4 mt-4">
          <button className="w-full bg-red-600/10 text-red-500 border border-red-500/30 py-4 rounded-xl font-black uppercase tracking-widest text-xs">
            Report Issue to Manager
          </button>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 w-full p-4 pb-10 bg-[#111a22]/90 backdrop-blur-md border-t border-white/10 flex flex-col gap-2 shadow-2xl">
        <button 
          onClick={() => navigate('/')}
          className="w-full bg-primary text-white py-5 rounded-2xl font-black text-xl shadow-[0_0_30px_rgba(19,127,236,0.3)] uppercase tracking-tight flex items-center justify-center gap-3 active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined text-2xl">check_circle</span>
          Finish & Notify Manager
        </button>
      </div>
    </div>
  );
};

export default OperatorWorkflow;
