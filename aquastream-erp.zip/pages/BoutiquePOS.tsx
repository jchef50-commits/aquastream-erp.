
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Product } from '../types';

const BoutiquePOS: React.FC = () => {
  const navigate = useNavigate();
  const [cartCount, setCartCount] = useState(0);

  const products: Product[] = [
    { id: 1, name: 'Ocean Breeze Scent', price: 2.99, stock: 12, image: 'https://images.unsplash.com/photo-1595433707802-68267d837c0a?auto=format&fit=crop&w=200&q=80' },
    { id: 2, name: 'Premium Microfiber XL', price: 12.50, stock: 3, image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=200&q=80' },
    { id: 3, name: 'Ceramic Quick Wax', price: 18.99, stock: 25, image: 'https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=200&q=80' },
    { id: 4, name: 'Tire Shine Pro Kit', price: 24.00, stock: 8, image: 'https://images.unsplash.com/photo-1598501479155-208d88321453?auto=format&fit=crop&w=200&q=80' },
    { id: 5, name: 'Streak-Free Glass', price: 7.95, stock: 15, image: 'https://images.unsplash.com/photo-1585671962215-473adff06c5b?auto=format&fit=crop&w=200&q=80' },
    { id: 6, name: 'Detailing Brush Set', price: 14.99, stock: 10, image: 'https://images.unsplash.com/photo-1518131348357-194165922301?auto=format&fit=crop&w=200&q=80' }
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-32">
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="flex items-center justify-between p-4 pb-2">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/')} className="flex items-center justify-center size-10 rounded-full hover:bg-slate-100">
              <span className="material-symbols-outlined text-slate-700">arrow_back</span>
            </button>
            <h1 className="text-xl font-black tracking-tight uppercase">Boutique POS</h1>
          </div>
          <button className="flex items-center justify-center size-10 rounded-full bg-secondary text-white shadow-lg shadow-secondary/30">
            <span className="material-symbols-outlined">barcode_scanner</span>
          </button>
        </div>
        <div className="px-4 py-3">
          <div className="relative group">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 group-focus-within:text-secondary">
              <span className="material-symbols-outlined text-xl">search</span>
            </span>
            <input 
              className="block w-full pl-11 pr-4 py-3 bg-slate-100 border-none rounded-xl focus:ring-2 focus:ring-secondary/50 placeholder-slate-400 font-medium" 
              placeholder="Search products or scan SKU..." 
              type="text"
            />
          </div>
        </div>
        <div className="overflow-x-auto no-scrollbar px-4 pb-3 flex gap-2">
          {['All', 'Accessories', 'Chemicals', 'Tools', 'Kits'].map((cat, idx) => (
            <button key={idx} className={`px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest whitespace-nowrap transition-all ${idx === 0 ? 'bg-secondary text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
              {cat}
            </button>
          ))}
        </div>
      </header>

      <main className="p-4 space-y-6">
        <section className="bg-secondary/5 border border-secondary/20 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-secondary/20 flex items-center justify-center text-secondary">
              <span className="material-symbols-outlined">directions_car</span>
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-secondary opacity-70">Linking Sale</p>
              <p className="font-black text-slate-800 tracking-tighter">Active Bay: ABC-1234</p>
            </div>
          </div>
          <button className="text-[10px] font-black text-secondary px-3 py-1.5 rounded-lg bg-white border border-secondary/20 hover:bg-secondary hover:text-white transition-all uppercase tracking-widest">
            Change
          </button>
        </section>

        <div className="grid grid-cols-2 gap-4">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 group">
              <div className="aspect-square bg-slate-100 relative overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                {product.stock <= 5 && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 bg-danger text-white text-[8px] font-black rounded uppercase tracking-widest">Low Stock</div>
                )}
                {product.stock > 10 && (
                   <div className="absolute top-2 right-2 px-2 py-0.5 bg-success text-white text-[8px] font-black rounded uppercase tracking-widest">In Stock</div>
                )}
              </div>
              <div className="p-3 space-y-2">
                <h3 className="font-bold text-xs text-slate-800 line-clamp-1 uppercase tracking-tighter leading-tight">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-black text-secondary tracking-tighter">${product.price.toFixed(2)}</span>
                  <button 
                    onClick={() => setCartCount(c => c + 1)}
                    className="size-8 rounded-lg bg-secondary text-white flex items-center justify-center active:scale-90 transition-transform shadow-md shadow-secondary/20"
                  >
                    <span className="material-symbols-outlined text-lg">add</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      <div className="fixed bottom-16 left-0 right-0 p-4 bg-white/95 backdrop-blur-lg border-t border-slate-200 z-40 max-w-md mx-auto">
        <div className="flex items-center gap-4">
          <div className="flex flex-col flex-1">
            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="material-symbols-outlined text-base">shopping_basket</span>
              <span className="text-[10px] font-black uppercase tracking-widest">{cartCount} Items in Cart</span>
            </div>
            <span className="text-2xl font-black text-slate-900 tracking-tighter">
              ${(cartCount * 11.49).toFixed(2)} <span className="text-[10px] font-medium text-slate-400 uppercase tracking-widest">Total</span>
            </span>
          </div>
          <button className="flex-1 bg-secondary hover:bg-secondary/90 text-white py-4 px-6 rounded-2xl font-black flex items-center justify-center gap-2 shadow-2xl shadow-secondary/30 active:scale-95 transition-all uppercase tracking-tighter text-sm">
            <span>Checkout</span>
            <span className="material-symbols-outlined">chevron_right</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default BoutiquePOS;
