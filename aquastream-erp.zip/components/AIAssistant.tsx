
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

interface AIAssistantProps {
  businessData: any;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ businessData }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Contexto del Lavadero: ${JSON.stringify(businessData)}. 
                  Usuario pregunta: ${userMessage}. 
                  Responde como un experto gerente de Car Wash, breve y profesional.`,
        config: {
          tools: [{ googleSearch: {} }]
        }
      });

      const aiText = response.text || "Lo siento, tuve un problema procesando eso.";
      setMessages(prev => [...prev, { role: 'model', text: aiText }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Error de conexión con el cerebro central." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-24 left-6 w-14 h-14 bg-gradient-to-tr from-primary to-blue-400 text-white rounded-full shadow-lg flex items-center justify-center z-50 animate-pulse active:scale-90 transition-transform ring-4 ring-white/50"
      >
        <span className="material-symbols-outlined text-2xl">psychology</span>
      </button>

      {/* Chat Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center p-4 bg-black/20 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl flex flex-col h-[70vh] border border-slate-200 overflow-hidden">
            <div className="p-4 bg-primary text-white flex justify-between items-center shrink-0">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined">smart_toy</span>
                <span className="font-bold">AquaStream AI Manager</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="material-symbols-outlined">close</button>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.length === 0 && (
                <div className="text-center py-10 text-slate-400 space-y-2">
                  <span className="material-symbols-outlined text-4xl opacity-20">auto_awesome</span>
                  <p className="text-xs font-bold uppercase tracking-widest">¿En qué puedo ayudarte hoy?</p>
                  <div className="flex flex-wrap gap-2 justify-center mt-4">
                    {["¿Cómo va el día?", "¿Por qué hay retrasos?", "Consejo de limpieza"].map(q => (
                      <button 
                        key={q} 
                        onClick={() => { setInput(q); }}
                        className="text-[10px] bg-white border border-slate-200 px-3 py-1.5 rounded-full hover:bg-primary hover:text-white transition-colors"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${m.role === 'user' ? 'bg-primary text-white rounded-tr-none' : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-sm'}`}>
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-tl-none flex gap-1">
                    <div className="size-1.5 bg-slate-300 rounded-full animate-bounce"></div>
                    <div className="size-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="size-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-white border-t border-slate-100 flex gap-2 items-center">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Pregunta a la IA..."
                className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-primary"
              />
              <button 
                onClick={handleSend}
                disabled={loading}
                className="size-10 bg-primary text-white rounded-xl flex items-center justify-center disabled:opacity-50"
              >
                <span className="material-symbols-outlined">send</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AIAssistant;
